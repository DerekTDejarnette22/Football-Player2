package com.codingdojo.createplayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreatePlayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
