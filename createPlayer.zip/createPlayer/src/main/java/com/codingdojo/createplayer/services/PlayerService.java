package com.codingdojo.createplayer.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.createplayer.models.Player;
import com.codingdojo.createplayer.repositories.PlayerRepository;
@Service
public class PlayerService {
	@Autowired
	private PlayerRepository repo;
	
	public Player findById(Long id) {
		
		Optional<Player> result = repo.findById(id);
		if(result.isPresent()) {
			return result.get();
		}
		
		return null;
	}
	

	public List<Player> all() {
		return repo.findAll();
	}
	
	public Player update(Player player) {
		return repo.save(player);
	}
	
	public Player create(Player player) {
		return repo.save(player);
	}
	
	public void deletePlayer(Player player) {
		repo.delete(player);
	}
}
