package com.codingdojo.createplayer.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.codingdojo.createplayer.models.LoginUser;
import com.codingdojo.createplayer.models.Player;
import com.codingdojo.createplayer.models.User;
import com.codingdojo.createplayer.services.PlayerService;
import com.codingdojo.createplayer.services.UserService;

@Controller
public class HomeController {

     @Autowired
     private UserService users;
     @Autowired
     private PlayerService players;
    
    @GetMapping("/")
    public String index(Model model) {
    
//lets you create a user and add them
        model.addAttribute("newUser", new User());
        model.addAttribute("newLogin", new LoginUser());
        return "index.jsp";
    }
    //register a user
    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("newUser") User newUser, 
            BindingResult result, Model model, HttpSession session) {
        

    	User user = users.register(newUser, result);
    	
        
        if(result.hasErrors()) {

            model.addAttribute("newLogin", new LoginUser());
            return "index.jsp";
        }
        
  
        session.setAttribute("userId", user.getId());
    
        return "redirect:/home";
    }
    
    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
            BindingResult result, Model model, HttpSession session) {
        
        User user = users.login(newLogin, result);
    
        if(result.hasErrors()) {
            model.addAttribute("newUser", new User());
            return "index.jsp";
        }
    
   
        session.setAttribute("userId", user.getId());
    
        return "redirect:/home";
    }
    
    @GetMapping("/home")
    public String home(Model model, HttpSession session) {
    	
    	if(session.getAttribute("userId") == null) {
    		return "redirect:/";
    	}
    	
    	model.addAttribute("players", players.all());
    	model.addAttribute("user", users.findById((Long)session.getAttribute("userId")));
    	return "home.jsp";
    }
    
    @GetMapping("/addPlayer")
    public String addPlayer(@ModelAttribute("player") Player player, Model model, HttpSession session) {
    	
    	User user = users.findById((Long)session.getAttribute("userId"));
    	model.addAttribute("user", user);
    	
    	return "newPlayer.jsp";
    }
	@RequestMapping("/players/delete/{id}")
	public String delete(@PathVariable("id") Long id, HttpSession session, Model model) {

		
		Player player = players.findById(id);

		players.deletePlayer(player);

		return "redirect:/home";
	}
	
    
    @PostMapping("/players")
    public String createPlayer(@Valid @ModelAttribute("player") Player player, BindingResult result) {

    	if (result.hasErrors()) {
    		return "newPlayer.jsp";
    	}
    	
    	players.create(player);
    	
    	return "redirect:/home";
    }
    
    @GetMapping("/players/{id}/edit")
    public String editPage(Model model, @PathVariable("id") Long id, HttpSession session) {
    	
    	if(session.getAttribute("userId") == null) {
    		return "redirect:/";
    	}
    	
    	Player player = players.findById(id);
    	model.addAttribute("player", player);
    	
    	return "editPlayer.jsp";
    }
    @GetMapping("/players/{id}")
    public String showPage(Model model, @PathVariable("id") Long id, HttpSession session) {
    	if(session.getAttribute("userId") == null) {
    		return "redirect:/";
    	}
    	Player player = players.findById(id);
    	model.addAttribute("player", player);
    	model.addAttribute("user", users.findById((Long)session.getAttribute("userId")));
    	
    	return "viewPlayer.jsp";
    }
    
    @PutMapping("/players/{id}")
    public String updateBook(@Valid @ModelAttribute("player") Player player, BindingResult result, Model model) {
    	
    	if (result.hasErrors()) {
    		return "editPlayer.jsp";
    	}
    	
    	System.out.println("Player will be saved to DB: " + player.getId());

        players.update(player);
        
    	
    	return "redirect:/home";
    }
    
    @GetMapping("/logout")
    public String logout(HttpSession session) {
    	session.invalidate();
    	return "redirect:/";
    }
}