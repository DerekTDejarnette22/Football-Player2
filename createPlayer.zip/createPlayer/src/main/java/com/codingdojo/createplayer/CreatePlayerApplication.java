package com.codingdojo.createplayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreatePlayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreatePlayerApplication.class, args);
	}

}
